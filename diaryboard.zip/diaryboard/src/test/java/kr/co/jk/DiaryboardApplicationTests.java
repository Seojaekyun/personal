package kr.co.jk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiaryboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
