package kr.co.jk.dto;

import lombok.Data;

@Data
public class DatDto {
	private int id,bid;
	private String pwd,nick,writeday,content;
	
	
}
