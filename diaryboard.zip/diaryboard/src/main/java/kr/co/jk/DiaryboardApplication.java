package kr.co.jk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiaryboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiaryboardApplication.class, args);
	}

}
